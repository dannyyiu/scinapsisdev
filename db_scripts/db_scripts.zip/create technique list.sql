DROP TABLE scin_db.pub_technique_list;
CREATE TABLE scin_db.pub_technique_list
(
  id              INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  parental_name    VARCHAR(100),
  alternative     VARCHAR(100)
);

DELETE FROM scin_db.pub_technique_list;
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','immunofluorescence');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','immunostaining');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','immunostained');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','confocal microscopy');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','stained');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','staining');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','fluorescence microscopy');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','microscopy');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','co-stained');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunofluorescence','co-staining');

INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','immunoprecipitation');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-immunoprecipitation');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-IP');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','precipitates');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','precipitated');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-precipitates');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-precipitated');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','immunoprecipitates');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','immunoprecipitated');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-immunoprecipitates');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunoprecipitation','co-immunoprecipitated');


INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','western blot');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','immunoblot');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','immunoblots');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','immunoblotting');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','immunoblotted');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','SDS-PAGE');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','SDS, PAGE');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','western blotting');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','western blots');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Western blot','western blotted');

INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Chromatin Immunoprecipitation','Chromatin Immunoprecipitation');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Chromatin Immunoprecipitation','ChIP');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Chromatin Immunoprecipitation','ChIP-qPCR');

INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunohistochemistry','Immunohistochemistry');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunohistochemistry','IHC');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('Immunohistochemistry','immunohistochemical');


INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('ELISA','ELISA');

INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('FACS','FACS');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('FACS','flow cytometry');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('FACS','flow-cytometry');
INSERT INTO scin_db.pub_technique_list (parental_name, alternative) VALUES ('FACS','flow, cytometry');